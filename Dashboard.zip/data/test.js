var oracledb = require('oracledb');
var fs = require('fs');
var config = require(__dirname + '/../config.js');
var async = require('async');
var queries;

function getQueries(cb) {
  fs.readFile(__dirname + '/../queries/queries.json', 'utf8', function (err, data) {
    if (err) {
      throw err;
    }

    queries = JSON.parse(data);
  });
}

function testGet(cb) {
  var num = 0;
  fs.readFile(__dirname + '/../queries/queries.json', 'utf8', function (err, data) {
    if (err) {
      throw err;
    }

    queries = JSON.parse(data);
    console.log("Queries object: " + queries);
  });
  oracledb.getConnection(
    config.database,
    function(err, connection) {
      if (err) {
        cb(err);

        return;
      }

      async.series([
        function(cb) {
          getQueries(cb);
          console.log('Query: ' + queries.ordersReceived);
        },
        function(cb) {
          connection.execute(
            queries.ordersReceived,
            {},
            {
              outFormat: oracledb.NUMBER
            },
            function(err, ordersReceivedNum) {
              if (err) {
                cb(err);

                return;
              }

              num = ordersReceivedNum;
            }
          )
        },
        function(err) {
          connection.release(function(err) {
            if (err) {
              console.error(err.message);
            }
          });

          if (err) {
            cb(err);
          } else {
            cb(null, num);
          }
        }
      ]);
    }
  );
}

module.exports.testGet = testGet;
