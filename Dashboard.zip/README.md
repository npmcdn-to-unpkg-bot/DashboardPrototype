# Dashboard Prototype
<b>Description:</b> Prototype for a dashboard using...
* Node.js
* D3.js
* jquery
