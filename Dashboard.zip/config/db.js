module.exports = {
    urlSubjectViews: ''
}
